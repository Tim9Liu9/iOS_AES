//
//  AppDelegate.h
//  AESDemo
//
//  Created by KFZXZHANGYS1 on 14/12/2.
//  Copyright (c) 2014年 kfzx-zhangys. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

